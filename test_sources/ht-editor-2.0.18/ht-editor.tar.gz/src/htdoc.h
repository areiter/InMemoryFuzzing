#ifndef __HTDOC_H
#define __HTDOC_H

extern
#ifdef __cplusplus
"C"
#endif
char htinfo[14764];

#endif /* __HTDOC_H */
