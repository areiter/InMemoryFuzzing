#ifndef __DEFREG_H
#define __DEFREG_H

extern
#ifdef __cplusplus
"C"
#endif
char default_reg[1591];

#endif /* __DEFREG_H */
